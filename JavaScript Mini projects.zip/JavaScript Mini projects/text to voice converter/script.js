document.getElementById('speak-btn').addEventListener('click', () => {
    const text = document.getElementById('text-input').value;
  
    if (text.trim() === '') {
      alert('Please enter some text to convert to speech.');
      return;
    }
  
    const speech = new SpeechSynthesisUtterance();
    speech.text = text;
    speech.lang = 'en-US'; 
    speech.rate = 1; 
    speech.pitch = 1; 
  
    window.speechSynthesis.speak(speech);
  });
  