// script.js
document.addEventListener("DOMContentLoaded", () => {
    const taskInput = document.getElementById("taskInput");
    const addTaskBtn = document.getElementById("addTaskBtn");
    const taskList = document.getElementById("taskList");
    addTaskBtn.addEventListener("click", () => {
      const taskText = taskInput.value.trim();
      if (taskText !== "") {
        addTask(taskText);
        taskInput.value = ""; 
      }
    });
    function addTask(task) {
      const listItem = document.createElement("li");
      const taskContent = document.createElement("span");
      taskContent.textContent = task;
      taskContent.addEventListener("click", () => {
        listItem.classList.toggle("completed");
      });   
      const deleteBtn = document.createElement("button");
      deleteBtn.textContent = "Delete";
      deleteBtn.classList.add("delete-btn");
      deleteBtn.addEventListener("click", () => {
        listItem.remove();
      });
      listItem.appendChild(taskContent);
      listItem.appendChild(deleteBtn);
      taskList.appendChild(listItem);
    }
  });
  